﻿'''
Country specific configurations.
'''
