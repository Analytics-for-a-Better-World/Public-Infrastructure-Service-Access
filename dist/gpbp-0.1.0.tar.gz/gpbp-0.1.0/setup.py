# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gpbp']

package_data = \
{'': ['*']}

install_requires = \
['descartes>=1.1.0,<2.0.0',
 'folium>=0.13.0,<0.14.0',
 'gadm>=0.0.3,<0.0.4',
 'geopandas>=0.11',
 'gurobipy>=10.0.0,<11.0.0',
 'hdx-python-api>=5.9.2,<6.0.0',
 'ipykernel>=6.16.2,<7.0.0',
 'jupyter-utils>=1.2.6,<2.0.0',
 'jupyter>=1.0.0,<2.0.0',
 'nbclient>=0.7.2,<0.8.0',
 'networkx>=2.8',
 'numpy>=1.23.5,<2.0.0',
 'osmnx>=1.2.2,<2.0.0',
 'osmxtract>=0.0.1,<0.0.2',
 'pandana @ '
 'git+https://github.com/UDST/pandana@09b51c4bed6c9067955fdb47789859510230c9cd',
 'pycountry>=22.3.5,<23.0.0',
 'pygeos==0.12',
 'pyomo>=6.4.3,<7.0.0',
 'pyproj>=3.3',
 'rasterio>=1.3.3,<2.0.0',
 'requests>=2.28',
 'rtree>=1.0',
 'scikit-learn>=1.1.3,<2.0.0',
 'setuptools>=65.6.0,<66.0.0',
 'shapely>=1.8.5.post1,<2.0.0',
 'streamlit-folium>=0.7.0,<0.8.0',
 'streamlit>=1.15.2,<2.0.0',
 'tables>=3.7.0,<4.0.0',
 'wget>=3.2,<4.0']

setup_kwargs = {
    'name': 'gpbp',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Public-Infrastructure-Location-Optimiser\n\n## References\n- [Travel Distance Calculations in Python](https://pythoncharmers.com/blog/travel-distance-python-with-geopandas-folium-alphashape-osmnx-buffer.html)\n- [Geocoding Services in Python](https://towardsdatascience.com/comparison-of-geocoding-services-applied-to-stroke-care-facilities-in-vietnam-with-python-ff0ba753a590)\n- [Visualising Global Population Datasets in Python](https://towardsdatascience.com/visualising-global-population-datasets-with-python-c87bcfc8c6a6)\n- [GPBP Publications - Temporary GitHub Repository](https://github.com/Analytics-for-a-Better-World/GPBP_Analytics_Tools)\n\n',
    'author': 'EiriniK',
    'author_email': 'Eirini.Kousathana@ortec.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
