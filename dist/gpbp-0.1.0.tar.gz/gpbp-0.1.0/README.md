# Public-Infrastructure-Location-Optimiser

## References
- [Travel Distance Calculations in Python](https://pythoncharmers.com/blog/travel-distance-python-with-geopandas-folium-alphashape-osmnx-buffer.html)
- [Geocoding Services in Python](https://towardsdatascience.com/comparison-of-geocoding-services-applied-to-stroke-care-facilities-in-vietnam-with-python-ff0ba753a590)
- [Visualising Global Population Datasets in Python](https://towardsdatascience.com/visualising-global-population-datasets-with-python-c87bcfc8c6a6)
- [GPBP Publications - Temporary GitHub Repository](https://github.com/Analytics-for-a-Better-World/GPBP_Analytics_Tools)

